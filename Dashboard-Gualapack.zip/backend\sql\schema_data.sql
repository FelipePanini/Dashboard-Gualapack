-- ============================================================================
-- Painel de Produção Gualapack — schema dos dados operacionais REAIS
-- Alvo: Supabase (Postgres 15+). Rode depois de schema.sql.
--
-- Cada tabela corresponde a uma aba de planilha real da pasta do Drive. O
-- mapeamento arquivo/aba -> tabela -> colunas está em TABLE_DEFS
-- (backend/sync-drive/lib.js) — é de lá que a carga lê.
--
-- Este arquivo descreve o banco como ele está HOJE. Migrações que já rodaram
-- no Supabase de produção foram tiradas daqui (ficam no histórico do git).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. Máquinas — catálogo (de "Machine Card Oficial")
-- ----------------------------------------------------------------------------
create table if not exists public.maquinas (
  id          text primary key,     -- ex: 'REB 01', 'R18', 'L02'
  grupo       text,                 -- 'CORTADEIRAS', 'FLEXOGRAFIA', 'LAMINADORAS', 'COATING', 'ROTOGRAVURA', 'HOT MELT'...
  considerar  text                  -- 'S' / 'N' (como vem na planilha)
);

-- ----------------------------------------------------------------------------
-- 1b. Cadastro oficial de código de apontamento -> classificação
--     (aba "Classificação Oficial" do Indicadores Diário, ~222 códigos).
--
--     É a definição do TMR. Antes a classificação vinha de uma COLUNA da aba
--     Base Apontamento; em 2026-09-18 essa coluna sumiu da planilha (a aba
--     caiu de 24 pra 22 colunas) e o TMR zerou em quase toda máquina, sem
--     erro nenhum na carga. Lendo do cadastro, a conta passa a depender de
--     uma tabela de códigos que muda raramente, e não do formato de uma aba.
--
--     cod_apont é texto de propósito: vem zero-padded ('01', '20', '40') e
--     tem que casar exatamente com apontamentos.cod_apont.
-- ----------------------------------------------------------------------------
create table if not exists public.classificacao_apontamento (
  cod                text primary key,   -- zero-padded ('01','20'); casa com apontamentos.cod_apont
  descricao          text,
  classificacao_disp text,               -- classificação de DISPONIBILIDADE — é a base do TMR
  classificacao      text,               -- classificação de HORAS
  _source_file       text
);

-- ----------------------------------------------------------------------------
-- 2. Apontamentos — eventos brutos de produção (de "Indicadores Diário" /
--    "Base Aparas"). É a maior e mais importante tabela — cada linha é um
--    evento de máquina (produzindo, parada, refugo, setup...).
--
--    Retenção: sync.js/ingest só gravam linhas com dt_producao dentro dos
--    últimos 12 meses (RETENTION_MONTHS) — planilhas antigas (ex: "Base
--    Aparas - 2024.xlsx") são lidas mas descartadas na carga, pra não
--    estourar o limite de armazenamento do plano free do Supabase de novo.
--
--    Sem chave natural nas linhas (é um log de eventos), então a carga
--    troca por arquivo: antes de inserir as linhas de um arquivo, apaga as
--    linhas que aquele MESMO arquivo gravou da vez anterior (por
--    _source_file) e insere as novas. Sem isso, rodar o sync todo dia sem
--    nenhuma chave de conflito faz cada linha ser inserida de novo do zero
--    a cada execução — foi exatamente isso que estourou o banco.
-- ----------------------------------------------------------------------------
create table if not exists public.apontamentos (
  id                  bigint generated always as identity primary key,
  _source_file        text,          -- nome do arquivo que gravou a linha (ver comentário acima)
  num_ordem           text,
  cod_recurso         text,
  cod_apont           text,          -- código do tipo de apontamento (ex: '20', '40')
  cod_desc            text,          -- descrição do apontamento (ex: '20 - Produzindo')
  dt_producao         date,
  hora_inicio         timestamptz,
  hora_fim            timestamptz,
  qtd_horas           numeric,
  qtd_produzida       numeric,
  turno               text,
  desperdicio_acerto  numeric,
  desperdicio_virando numeric,
  peso_bruto_bobina   numeric,
  tipo_perda          text,          -- usr_tipodaperda (ex: '06_Falha_de_Laminaca')
  kg_perda            numeric,       -- usr_kgdaperda
  nome_operador       text,
  tipo_produto        text,
  cod_estrutura       text,
  des_num_ordem       text,          -- descrição do produto/ordem
  cod_est             text,
  processo            text,          -- 'Impressão', 'Laminação', 'Corte'...
  classificacao       text,          -- família de produto
  nome_cliente         text,
  -- Só existem na aba [Base Apontamento] (fonte do TMR desde 2026-09-10).
  -- classificacao_disp: PLANEJADO / IMPRODUTIVO / PRODUZINDO. O TMR usa esta
  -- coluna e, quando ela vem vazia, cai no cadastro classificacao_apontamento
  -- pelo cod_apont (ver rpc_maquinas_resumo em schema_views.sql).
  classificacao_disp   text,
  classificacao_horas  text
);

create index if not exists idx_apontamentos_data on public.apontamentos (dt_producao desc);
create index if not exists idx_apontamentos_recurso on public.apontamentos (cod_recurso, dt_producao desc);
create index if not exists idx_apontamentos_source on public.apontamentos (_source_file);

-- ----------------------------------------------------------------------------
-- 3. Fardos de aparas — um por fardo (de "SEQUENCIAMENTO DOS FARDOS DE
--    APARAS JGR" mensal e "Sequenciamento Acumulado")
--    Mesma troca-por-arquivo da tabela apontamentos (ver comentário lá).
-- ----------------------------------------------------------------------------
create table if not exists public.fardos_aparas (
  id              bigint generated always as identity primary key,
  _source_file    text,          -- nome do arquivo que gravou a linha
  codigo          text,          -- código da classificação (numérico, ex: '1', '11')
  dp_fp           text,          -- 'DP' ou 'FP'
  refugo          text,          -- 'X' ou vazio
  refile          text,          -- 'X' ou vazio
  data            date,
  numero          int,           -- Nº do fardo no dia
  qtd_bruta_kg    numeric,
  qtd_liquida_kg  numeric,
  nome            text,          -- operador
  classificacao   text,          -- texto da classificação (ex: 'PROCESSO PRODUTIVO', 'REFILE')
  tipo            text
);

create index if not exists idx_fardos_aparas_data on public.fardos_aparas (data desc);
create index if not exists idx_fardos_aparas_source on public.fardos_aparas (_source_file);

-- ----------------------------------------------------------------------------
-- 4. Aderência — apontamentos de produção por máquina/dia (de "Aderência
--    Máquinas - Diária", aba "Apontamentos_produção").
--    SEM CARGA HOJE: esse arquivo não existe mais na pasta do Drive, então a
--    tabela fica vazia. Mantida porque o upload manual ainda escreve nela.
-- ----------------------------------------------------------------------------
create table if not exists public.aderencia_maquinas_diaria (
  id             bigint generated always as identity primary key,
  _source_file   text,          -- nome do arquivo que gravou a linha
  num_ordem      text,
  dt_producao    date,
  qtd_produzida  numeric,
  cod_recurso    text,
  qtd_horas      numeric,
  classificacao  text,
  descricao      text,
  cod_estrutura  text,
  turno          text,
  cod_desc       text,
  cod_apont      text
);

create index if not exists idx_aderencia_maq_data on public.aderencia_maquinas_diaria (dt_producao desc);
create index if not exists idx_aderencia_maq_source on public.aderencia_maquinas_diaria (_source_file);

-- ----------------------------------------------------------------------------
-- 5. Aderência à programação (de "Aderência Semanal.xlsx", aba "ADERÊNCIA
--    DIÁRIA": planejado e produzido já cruzados na mesma linha).
--    Mesma retenção de 12 meses (por dt_ini_plan) e troca-por-arquivo da
--    tabela apontamentos. Fonte trocada em 2026-09-11 — histórico no
--    TABLE_DEFS de aderencia_programacao em backend/sync-drive/lib.js.
-- ----------------------------------------------------------------------------
create table if not exists public.aderencia_programacao (
  id             bigint generated always as identity primary key,
  _source_file   text,          -- nome do arquivo que gravou a linha
  num_ordem      text,
  maquina        text,
  dt_ini_plan    date,
  qtd_planejada  numeric,
  produto        text,
  qtd_produzida  numeric,
  ano            numeric,
  base           text,
  dt_entrega     date
);

create index if not exists idx_aderencia_prog_data on public.aderencia_programacao (dt_ini_plan desc);
create index if not exists idx_aderencia_prog_maquina on public.aderencia_programacao (maquina, dt_ini_plan desc);
create index if not exists idx_aderencia_prog_source on public.aderencia_programacao (_source_file);

-- ----------------------------------------------------------------------------
-- 6. Refugo/aparas — série histórica mensal (de "Refugo Aparas")
-- ----------------------------------------------------------------------------
create table if not exists public.refugo_aparas_historico (
  id          bigint generated always as identity primary key,
  data        date not null,
  volume_jgr  numeric,
  scrap_jgr   numeric,
  volume_orf  numeric,
  scrap_orf   numeric,
  unique (data)
);

-- ----------------------------------------------------------------------------
-- 7. Tendência mensal — pré-agregado (de "Graficos Tendência")
-- ----------------------------------------------------------------------------
create table if not exists public.tendencia_mensal (
  id                   bigint generated always as identity primary key,
  mes                  text not null,  -- ex: 'Janeiro', 'W-27'
  ano                  int,
  volume_prod_corte_km numeric,
  lote_medio_km        numeric,
  volume_prod_kg       numeric,
  aparas_kg            numeric,
  aparas_pct           numeric,
  unique (mes, ano)
);

-- ----------------------------------------------------------------------------
-- 6b. Refugo por evento/máquina/motivo (de "Refugo Produção.xlsx", aba
--     "Consulta Perda") — log de evento, sem chave natural, mesma troca-
--     por-arquivo e retenção de 12 meses da tabela apontamentos.
-- ----------------------------------------------------------------------------
create table if not exists public.refugo_producao (
  id            bigint generated always as identity primary key,
  _source_file  text,
  op            text,
  maquina       text,
  turno         numeric,
  dt_producao   date,
  cod_apont     text,
  operador      text,
  processo      text,
  tipo          text,     -- motivo do refugo, ex: '05_Acerto_de_Cor'
  kg_perda      numeric,
  dia           numeric,
  chave_1       text,
  mes           numeric
);

create index if not exists idx_refugo_producao_data on public.refugo_producao (dt_producao desc);
create index if not exists idx_refugo_producao_source on public.refugo_producao (_source_file);

-- ----------------------------------------------------------------------------
-- 6c. Produção/refugo em kg por ordem (de "Indicadores Diário - AAAA.xlsx",
--     aba "Base Apontamentos (kg)") — separado de "apontamentos" (que vem
--     da aba "Base Apontamento" e tem os campos de TMR/Gantt/parada).
--     É a fonte da apara por máquina (peso bruto e refugo na mesma linha).
--     Mesma troca-por-arquivo e retenção de 12 meses.
-- ----------------------------------------------------------------------------
create table if not exists public.producao_kg (
  id            bigint generated always as identity primary key,
  _source_file  text,
  num_ordem     text,
  cod_recurso   text,
  dt_producao   date,
  turno         text,
  peso_bruto    numeric,
  refugo        numeric,
  descricao     text,
  estrutura     text,
  processo      text,
  tipo_produto  text,
  considerar    text,
  planta        text,
  maquina_real  text,
  chave         text
);

create index if not exists idx_producao_kg_data on public.producao_kg (dt_producao desc);
create index if not exists idx_producao_kg_source on public.producao_kg (_source_file);

-- ----------------------------------------------------------------------------
-- 7b. Scrap % mensal, direto do Power BI da Gualapack (de "Sequenciamento
--     Acumulado 2026 Rev2.xlsx", aba "Percentual Scrap BI") — produção e
--     refugo total já fechados por mês. NÃO é o mesmo número que
--     fardos_aparas/kg_perda de apontamentos (confirmado com o usuário em
--     2026-09-16: escala ~4-5x maior, é produção geral das máquinas, não só
--     o que virou apara) — existe como referência direta pro % que o BI já
--     mostra, sem tentar recalcular a partir de outra fonte.
-- ----------------------------------------------------------------------------
create table if not exists public.scrap_bi_mensal (
  id             bigint generated always as identity primary key,
  _source_file   text,
  data           date not null,
  producao       numeric,
  refugo_total   numeric,
  unique (data)
);

create index if not exists idx_scrap_bi_mensal_data on public.scrap_bi_mensal (data desc);

-- ----------------------------------------------------------------------------
-- 7c. Produção em metros/m² por OP/máquina/dia (de "Machine Card Oficial -
--     *.xlsx", aba PRODUCAO_METROS) — a única base com m² e LARGURA REAL.
--     É o que alimenta os KPIs de Produtividade (m²/h) e Velocidade (m/min),
--     que ficaram vazios no painel até 2026-09-16. Era inventário
--     (bases-catalog.js) e foi promovida a tabela; a tentativa antiga de
--     buscar isso direto no SQL Server foi abandonada justamente porque o
--     mesmo dado já chega pela planilha do Machine Card.
-- ----------------------------------------------------------------------------
create table if not exists public.producao_metros (
  id               bigint generated always as identity primary key,
  _source_file     text,
  num_ordem        text,
  cod_recurso      text,
  dt_producao      date,
  tipo_produto     text,
  descricao        text,
  operador         text,
  turno            numeric,
  qtd_horas        numeric,
  qtd_produzida_m  numeric,   -- metros lineares
  producao_m2      numeric,   -- metros lineares x largura real
  largura_real     numeric
);

create index if not exists idx_producao_metros_data on public.producao_metros (dt_producao desc);
create index if not exists idx_producao_metros_recurso on public.producao_metros (cod_recurso, dt_producao desc);
create index if not exists idx_producao_metros_source on public.producao_metros (_source_file);

-- ----------------------------------------------------------------------------
-- 8. RLS — leitura para qualquer usuário autenticado, escrita só via
--    service_role (sync.js no GitHub Actions e a função "ingest" do upload
--    manual — nunca o navegador direto).
-- ----------------------------------------------------------------------------
alter table public.maquinas                   enable row level security;
alter table public.apontamentos               enable row level security;
alter table public.fardos_aparas              enable row level security;
alter table public.aderencia_maquinas_diaria  enable row level security;
alter table public.aderencia_programacao      enable row level security;
alter table public.refugo_aparas_historico    enable row level security;
alter table public.tendencia_mensal           enable row level security;
alter table public.refugo_producao            enable row level security;
alter table public.producao_kg                enable row level security;
alter table public.scrap_bi_mensal             enable row level security;
alter table public.producao_metros             enable row level security;
alter table public.classificacao_apontamento   enable row level security;

do $$
declare t text;
begin
  foreach t in array array[
    'maquinas','apontamentos','fardos_aparas','aderencia_maquinas_diaria',
    'aderencia_programacao','refugo_aparas_historico','tendencia_mensal',
    'refugo_producao','producao_kg','scrap_bi_mensal','producao_metros',
    'classificacao_apontamento'
  ]
  loop
    -- drop antes de criar pra esse script poder ser rodado de novo sem
    -- erro de "policy already exists" (create policy não tem IF NOT EXISTS)
    execute format('drop policy if exists "%1$s: leitura por usuário autenticado" on public.%1$s;', t);
    execute format(
      'create policy "%1$s: leitura por usuário autenticado" on public.%1$s for select to authenticated using (true);',
      t
    );
  end loop;
end $$;

-- ----------------------------------------------------------------------------
-- 9. Log da carga — pra conferir se um upload rodou e o que veio
-- ----------------------------------------------------------------------------
create table if not exists public.sync_log (
  id          bigint generated always as identity primary key,
  started_at  timestamptz not null default now(),
  finished_at timestamptz,
  status      text not null default 'running' check (status in ('running','ok','error')),
  detalhe     text,
  linhas_gravadas int
);

alter table public.sync_log enable row level security;

drop policy if exists "sync_log: admin lê o histórico de carga" on public.sync_log;

create policy "sync_log: admin lê o histórico de carga"
  on public.sync_log for select
  to authenticated
  using (
    exists (select 1 from public.profiles where profiles.id = auth.uid() and profiles.role = 'admin')
  );
